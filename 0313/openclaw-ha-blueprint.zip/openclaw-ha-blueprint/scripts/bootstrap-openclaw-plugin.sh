#!/usr/bin/env bash
set -euo pipefail

docker compose exec openclaw-cli openclaw plugins install /project/plugins/openclaw-plugin-ha-control
docker compose restart openclaw-gateway
