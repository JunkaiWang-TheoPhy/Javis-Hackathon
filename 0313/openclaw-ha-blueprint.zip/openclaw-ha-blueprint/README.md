# OpenClaw × Home Assistant runnable blueprint

This project is a runnable skeleton for:

- high-heart-rate alert handling from a wearable webhook
- arrival-home cooling response
- mechanical-switch actuation through Home Assistant entities
- OpenClaw tool exposure through an `ha-control` plugin

## Layout

- `plugins/openclaw-plugin-ha-control/`
  - OpenClaw plugin with typed tools, webhook route, HA WebSocket presence watcher, and shipped skill.
- `openclaw-config/openclaw.json`
  - OpenClaw config pointing at Home Assistant and the local plugin path.
- `homeassistant-config/`
  - Minimal HA config for local API + conversation.
- `docker-compose.yml`
  - Home Assistant + Ollama + OpenClaw gateway/CLI.
- `scripts/`
  - Demo scripts for posting a heart-rate event and simulating arrival home.

## What is production-ready here

- Plugin manifest (`openclaw.plugin.json`)
- Plugin tool registration (`api.registerTool`)
- Plugin HTTP webhook registration (`api.registerHttpRoute`)
- Plugin background service for HA presence watching (`api.registerService`)
- HA REST / WebSocket API usage
- Docker services using the official OpenClaw image path

## What you must edit before first real run

1. In `openclaw-config/openclaw.json`, replace:
   - `REPLACE_ME_HA_LONG_LIVED_TOKEN`
   - `switch.third_reality_wall_switch`
   - `switch.switchbot_bot`
   - optional `scene.demo_cooling_after_workout` with your real `scene.*`
   - optional `fanEntityId` / `climateEntityId` if you want direct fan/climate control instead of a scene
2. Install the local plugin into OpenClaw (this copies it into `~/.openclaw/extensions` and installs its pure JS dependencies):

```bash
./scripts/bootstrap-openclaw-plugin.sh
```

3. Pull an Ollama model inside the Ollama container, for example:

```bash
docker compose exec ollama ollama pull glm-4.7-flash
```

## Bring-up

### 1. Start services

```bash
docker compose up -d
```

### 2. Generate or copy a Home Assistant long-lived access token

- Open Home Assistant at `http://127.0.0.1:8123`
- Create a user token in your profile
- Paste it into `openclaw-config/openclaw.json`

### 3. Install the plugin into OpenClaw and restart the gateway

```bash
./scripts/bootstrap-openclaw-plugin.sh
docker compose restart openclaw-gateway
```

### 4. Pull an Ollama model

```bash
docker compose exec ollama ollama pull glm-4.7-flash
```

### 5. Open the OpenClaw control UI

The gateway listens on port `18789`. If the browser asks for pairing or authorization, generate a fresh dashboard link from the CLI container:

```bash
docker compose exec openclaw-cli openclaw dashboard --no-open
```

Then open the printed URL in your browser.

### 6. Optional: simulate the end-to-end flow

```bash
HA_TOKEN=YOUR_TOKEN ./scripts/demo-sequence.sh
```

This performs:

1. wearable webhook posts a sustained high-HR event while away
2. Home Assistant state for `device_tracker.demo_user` is set to `home`
3. the plugin's WebSocket watcher sees `state_changed`
4. if the recent-HR window is still valid, the plugin runs the cooling response

## End-to-end call chain

### A. High heart rate while at home

1. Wearable bridge posts JSON to:
   - `POST /ha-control/webhooks/wearable`
2. Plugin validates `x-ha-control-secret`
3. Plugin evaluates thresholds from `plugins.entries.ha-control.config.policies`
4. Plugin mirrors state into custom HA entities:
   - `sensor.openclaw_latest_heart_rate`
   - `binary_sensor.openclaw_recent_high_hr`
5. Plugin sends a notification via configured HA service
6. Plugin runs either:
   - `scene.turn_on` on `coolingSceneEntityId`, or
   - `fan.turn_on` + `climate.set_temperature` (+ optional `climate.set_hvac_mode`)
7. If configured, plugin also calls:
   - `switch.turn_on` on Third Reality / SwitchBot entities

### B. High heart rate while away, then arriving home

1. Wearable webhook stores a recent high-HR event in plugin memory
2. HA WebSocket watcher subscribes to `state_changed`
3. When `presenceEntityId` changes to `home`, the plugin checks the recent-HR window
4. If valid, it notifies and runs the configured cooling response
5. Mechanical switches are toggled if `mechanicalSwitch.onArrivalCooling=true`

### C. Manual / agent-driven control

The plugin ships these OpenClaw tools:

- `ha_get_state`
- `ha_call_service`
- `ha_process_conversation`
- `home_run_cooling_scene`
- `home_handle_hr_event`

The shipped skill `home-assistant-control` tells the model when to use each one.

## Notes

- The included `scene.demo_cooling_after_workout` only toggles demo helpers. Replace it with a real `scene.*` or real `fan.*` / `climate.*` entities for production.
- For purely local mechanical switching, prefer Home Assistant entities backed by local Zigbee/Matter/Bluetooth integrations.
